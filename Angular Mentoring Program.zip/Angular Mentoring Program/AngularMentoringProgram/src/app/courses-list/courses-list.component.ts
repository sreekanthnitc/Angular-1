import { Component, OnInit, Input } from '@angular/core';
import { ListType } from '../static-data';

@Component({
  selector: 'app-courses-list',
  templateUrl: './courses-list.component.html',
  styleUrls: ['./courses-list.component.less']
})
export class CoursesListComponent implements OnInit {

  @Input() list: ListType;
  constructor() { }

  ngOnInit() {
  }

}
