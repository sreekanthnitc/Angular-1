import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-section',
  templateUrl: './footer-section.component.html',
  styleUrls: ['./footer-section.component.less']
})
export class FooterSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
